---
name: Magenta Flora Modern
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#5a4044'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#8e6f74'
  outline-variant: '#e3bdc3'
  surface-tint: '#bc004f'
  primary: '#b0004a'
  on-primary: '#ffffff'
  primary-container: '#d81b60'
  on-primary-container: '#fff2f3'
  inverse-primary: '#ffb2bf'
  secondary: '#586062'
  on-secondary: '#ffffff'
  secondary-container: '#dae1e3'
  on-secondary-container: '#5d6466'
  tertiary: '#5d565a'
  on-tertiary: '#ffffff'
  tertiary-container: '#766e72'
  on-tertiary-container: '#fdf2f7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9de'
  primary-fixed-dim: '#ffb2bf'
  on-primary-fixed: '#3f0016'
  on-primary-fixed-variant: '#90003b'
  secondary-fixed: '#dde4e6'
  secondary-fixed-dim: '#c1c8ca'
  on-secondary-fixed: '#161d1f'
  on-secondary-fixed-variant: '#41484a'
  tertiary-fixed: '#eae0e5'
  tertiary-fixed-dim: '#cec4c9'
  on-tertiary-fixed: '#1f1a1e'
  on-tertiary-fixed-variant: '#4b4549'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  section-gap: 80px
---

## Brand & Style

The design system creates a premium boutique experience that transforms a traditional florist into a modern digital gifting destination. The personality is **elegant, fresh, and vibrant**, moving away from "e-commerce utility" toward "editorial luxury." 

By blending **Minimalism** with **Corporate Modern** sensibilities, the UI uses expansive whitespace to let product photography breathe, functioning like a high-end gallery. The emotional response is one of joy and sophistication—evoking the feeling of receiving a hand-delivered bouquet. Contrast is intentionally high to ensure accessibility while maintaining a sharp, contemporary edge.

## Colors

The palette is anchored by a **Vibrant Magenta (#D81B60)**, chosen for its energy and modern floral association. This is supported by a deep **Charcoal (#2D3436)** for typography to ensure maximum legibility and a premium feel.

- **Primary:** Magenta serves as the "action" color for CTAs, highlights, and brand signals.
- **Secondary:** Deep charcoal for body text and primary headings.
- **Tertiary:** A soft pink-wash neutral (#FDF2F7) used for background sections to create subtle depth without clashing with photography.
- **Status:** Success (Emerald), Error (Crimson), and Warning (Amber) are used sparingly in functional contexts.

## Typography

This design system utilizes a dual-sans-serif pairing to achieve a "Modern Boutique" aesthetic. 

**Manrope** is used for headings and structural labels; its geometric yet warm construction provides a professional and trustworthy backbone. **Plus Jakarta Sans** is utilized for body copy and descriptions, offering a softer, more approachable feel that remains highly readable at smaller scales.

Large display type should use tight tracking (-0.02em) to feel cohesive and impactful, while labels use expanded tracking (+0.05em) and uppercase styling to provide clear functional separation.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop (12 columns) and a **Fluid Grid** on mobile (4 columns). 

1. **Rhythm:** An 8px linear scale governs all padding and margins to maintain mathematical harmony. 
2. **Generous Breathing Room:** Sections are separated by a minimum of 80px on desktop to prevent the "cluttered" look of traditional e-commerce.
3. **Product Grids:** Flower cards use a 24px gutter to ensure that vibrant floral colors do not bleed into adjacent items visually.
4. **Breakpoints:**
   - Mobile: < 600px (Margins: 16px)
   - Tablet: 600px - 1024px (Margins: 32px)
   - Desktop: > 1024px (Max Container: 1280px)

## Elevation & Depth

Visual hierarchy is established through **Tonal Layering** and **Soft Ambient Shadows**. This design system avoids harsh borders in favor of depth created by light.

- **Level 0 (Surface):** Pure white (#FFFFFF) for the primary background.
- **Level 1 (Cards/Inputs):** Subtle 1px border in #EEEEEE or a very soft shadow (0px 4px 20px rgba(0,0,0,0.04)).
- **Level 2 (Hover/Modals):** More pronounced elevation (0px 12px 30px rgba(0,0,0,0.08)) to indicate interactivity.
- **Glassmorphism:** Navigation bars use a backdrop-blur (12px) with 90% opacity white to maintain context of the vibrant floral imagery as the user scrolls.

## Shapes

The shape language is **Rounded (0.5rem)**, striking a balance between the organic nature of flowers and the precision of modern tech.

- **Small elements:** (Tags, Checkboxes) use 4px radius.
- **Standard elements:** (Buttons, Input Fields, Cards) use 8px (0.5rem) radius.
- **Large elements:** (Feature Banners, Hero Images) use 16px (1rem) radius.
- **Interactive Pill:** Secondary buttons and search bars may use a full pill-shape (999px) to invite touch.

## Components

### Buttons
- **Primary:** Solid Magenta background, White text. High-contrast, 0.5rem corner radius. Use a subtle scale-down (0.98) on click for tactile feedback.
- **Secondary:** Magenta outline (2px) with transparent background. Used for "View More" or secondary actions.

### Product Cards
- Cards feature a borderless design on Level 0 surfaces, relying on white space. 
- Product titles use `headline-sm` in Charcoal.
- Prices are highlighted in `headline-sm` but using the Primary Magenta color to draw the eye.

### Input Fields
- High-affordance borders (1px #DDD) that transition to Magenta on focus. 
- Labels utilize `label-sm` floating above the field for a clean, modern look.

### Accordions (Q&A)
- Minimalist style with thin horizontal separators. 
- Use the Primary Magenta for the "plus/minus" or "chevron" icons to create interactive focal points.

### Chips/Badges
- Small, rounded-pill shapes used for "Same Day Delivery" or "Best Seller." 
- Use Tertiary Magenta (#FDF2F7) background with Primary Magenta text for a soft, premium look.